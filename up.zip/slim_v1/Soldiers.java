package slim_v1;

import battlecode.common.*;

public class Soldiers extends RobotPlayer {

    static MapLocation target;

    // how long of not being able to reach target till we change it?
    static int targetChangeWaitTime = Math.max(mapWidth, mapHeight);

    // run() function specific globals
    static int lastTargetChangeRound = 9999;

    public static void run() throws GameActionException {

        if (isFillingRuin && rc.canSenseRobotAtLocation(curRuin.getMapLocation())) {
            isFillingRuin = false;
            curRuin = null;
        }
        // Ruin
        UnitType buildTowerType = AuxConstants.buildOrder[rc.getNumberTowers() - 1];

        if (rc.getNumberTowers() == GameConstants.MAX_NUMBER_OF_TOWERS) {
            isFillingRuin = false;
        }

        if (isFillingRuin) {  // prefer checking isFillingRuin over curRuin == null
            rc.setIndicatorDot(curRuin.getMapLocation(), 255, 0, 0);
            boolean noEnemyPaint = FillRuin.updateNearestWrongInRuin(buildTowerType);
            if (noEnemyPaint) {
                HeuristicPath.moveToWrongInRuin();
                FillRuin.updateNearestWrongInRuin(buildTowerType);

                if (rc.canCompleteTowerPattern(buildTowerType, curRuin.getMapLocation())) {
                    rc.completeTowerPattern(buildTowerType, curRuin.getMapLocation());
                }

                if (nearestWrongInRuin != null) rc.setIndicatorDot(nearestWrongInRuin, 255, 255, 0);

                FillRuin.tryToPaintRuin(buildTowerType);

                if (rc.getPaint() < 30) {  // we cannot finish the ruin and must refill
                    isFillingRuin = false;
                }
                return;
            } else {
                isFillingRuin = false;
                nearestWrongInRuin = null;
            }
        }
        // SRP
        else if (isFillingSRP) {
            rc.setIndicatorDot(curSRP, 255, 0, 0);
            boolean noEnemyPaint = FillSRP.updateNearestWrongInSRP();
            if (noEnemyPaint) {
                HeuristicPath.moveToWrongInSRP();
                FillSRP.updateNearestWrongInSRP();

                if (nearestWrongInSRP != null) rc.setIndicatorDot(nearestWrongInSRP, 255, 255, 0);

                FillSRP.tryToPaintSRP();

                if (rc.getPaint() < 5) {
                    isFillingRuin = false;
                }
                return;
            } else {
                isFillingSRP = false;
                nearestWrongInSRP = null;
            }
        }

        nearbyTiles = rc.senseNearbyMapInfos();

        ImpureUtils.updateNearestEnemyTower();
        ImpureUtils.tryMarkSRP();

        if (!isRefilling) {
            int distance = (int)2e9;
            for (MapInfo tile : nearbyTiles) {
                if (tile.hasRuin()) {
                    if (!rc.canSenseRobotAtLocation(tile.getMapLocation())) {
                        if (tile.getMapLocation().distanceSquaredTo(rc.getLocation()) < distance) {
                            distance = tile.getMapLocation().distanceSquaredTo(rc.getLocation());
                            curRuin = tile;
                            isFillingRuin = true;
                        }
                    }
                }
            }
        }

        if (!isRefilling && !isFillingRuin) {
            int distance = (int)2e9;
            for (MapInfo tile : nearbyTiles) {
                if (tile.getMark() == PaintType.ALLY_PRIMARY) {
                    if (tile.getMapLocation().distanceSquaredTo(rc.getLocation()) < distance) {
                        MapLocation nearestWrongOnIt = FillSRP.pureNearestWrongInSRP(tile.getMapLocation());
                        if (nearestWrongOnIt != null) {
                            distance = tile.getMapLocation().distanceSquaredTo(rc.getLocation());
                            curSRP = tile.getMapLocation();
                            isFillingSRP = true;
                        }
                    }
                }
            }
        }


        MapLocation paintTarget = nearestPaintTower;
        if (paintTarget == null) paintTarget = spawnTowerLocation;
        ImpureUtils.withdrawPaintIfPossible(paintTarget);

        if (rc.getPaint() < 100) {
            isRefilling = true;
        } else {
            isRefilling = false;
        }

        if (isRefilling) {
            HeuristicPath.targetIncentive = 1000;
            HeuristicPath.move(paintTarget);
            ImpureUtils.paintFloor();
            rc.setIndicatorLine(rc.getLocation(), paintTarget, 131, 252, 131);
        }


        if (target == null
                || rc.getLocation().isWithinDistanceSquared(target, 9)
                || rc.getRoundNum() - lastTargetChangeRound > targetChangeWaitTime) {
            if (target != null) rc.setIndicatorDot(target, 0, 0, 0);
            target = new MapLocation(rng.nextInt(mapWidth-1), rng.nextInt(mapHeight-1));
            lastTargetChangeRound = rc.getRoundNum();
        }
        rc.setIndicatorDot(target, 200, 200, 200);

        if (rc.isMovementReady()) {
            HeuristicPath.targetIncentive = 500;
            HeuristicPath.move(target);
        }

        ImpureUtils.paintFloor();
    }

}
